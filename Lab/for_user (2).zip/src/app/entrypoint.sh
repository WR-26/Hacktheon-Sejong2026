#!/bin/sh
set -e

CERT_DIR=${CERT_DIR:-/certs}
PORT=${PORT:-443}

python -c "
import os, psycopg2
try:
    db = psycopg2.connect(os.environ.get('DATABASE_URL','postgresql://app:secret@db/phantompass'))
    cur = db.cursor()
    cur.execute(\"ALTER TABLE posts ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW()\")
    cur.execute(\"DELETE FROM creds WHERE uid IN (SELECT id FROM users WHERE name=%s)\", ('${ADMIN_USER:-admin}',))
    cur.execute(\"DELETE FROM posts WHERE uid IN (SELECT id FROM users WHERE name=%s)\", ('${ADMIN_USER:-admin}',))
    cur.execute(\"DELETE FROM users WHERE name=%s\", ('${ADMIN_USER:-admin}',))
    db.commit()
    print(f'[entrypoint] migrate + admin reset done')
    db.close()
except Exception as e:
    print(f'[entrypoint] admin reset skipped: {e}')
"

if [ "$HTTPS" = "true" ] || [ "$HTTPS" = "1" ]; then
    mkdir -p "$CERT_DIR"
    if [ ! -f "$CERT_DIR/cert.pem" ]; then
        python -c "
from OpenSSL import crypto
import os
key = crypto.PKey()
key.generate_key(crypto.TYPE_RSA, 2048)
cert = crypto.X509()
cert.get_subject().CN = os.environ.get('RP_ID', 'localhost')
cert.set_serial_number(1000)
cert.gmtime_adj_notBefore(0)
cert.gmtime_adj_notAfter(365*24*60*60)
cert.set_issuer(cert.get_subject())
cert.set_pubkey(key)
cert.sign(key, 'sha256')
d = os.environ.get('CERT_DIR', '/certs')
open(f'{d}/cert.pem','wb').write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert))
open(f'{d}/key.pem','wb').write(crypto.dump_privatekey(crypto.FILETYPE_PEM, key))
print('[entrypoint] cert generated')
"
    fi
    exec gunicorn -w "${WORKERS:-4}" -b "0.0.0.0:${PORT}" \
        --certfile="$CERT_DIR/cert.pem" --keyfile="$CERT_DIR/key.pem" \
        --timeout 30 --access-logfile - app:app
else
    exec gunicorn -w "${WORKERS:-4}" -b "0.0.0.0:${PORT}" \
        --timeout 30 --access-logfile - app:app
fi
