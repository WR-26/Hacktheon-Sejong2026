function b64url(buf){return btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function b64decode(s){return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0))}
function msg(t){document.getElementById('msg').textContent=t}

async function doRegister(){
  try{
    const u=document.getElementById('user').value;
    if(!u){msg('Enter username');return}
    const r=await fetch('/api/register/begin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u})});
    if(!r.ok){msg((await r.json()).error);return}
    const opts=await r.json();
    opts.challenge=b64decode(opts.challenge);
    opts.user.id=b64decode(opts.user.id);
    if(opts.excludeCredentials)opts.excludeCredentials.forEach(c=>c.id=b64decode(c.id));
    const cred=await navigator.credentials.create({publicKey:opts});
    const body={id:cred.id,rawId:b64url(cred.rawId),type:cred.type,
      response:{attestationObject:b64url(cred.response.attestationObject),clientDataJSON:b64url(cred.response.clientDataJSON)},
      authenticatorAttachment:cred.authenticatorAttachment};
    const r2=await fetch('/api/register/complete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if(r2.ok){location.href='/dashboard'}else{msg((await r2.json()).error)}
  }catch(e){msg('Error: '+e.message)}
}

async function doLogin(){
  try{
    const r=await fetch('/api/login/begin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});
    if(!r.ok){msg((await r.json()).error);return}
    const opts=await r.json();
    opts.challenge=b64decode(opts.challenge);
    if(opts.allowCredentials)opts.allowCredentials.forEach(c=>c.id=b64decode(c.id));
    const cred=await navigator.credentials.get({publicKey:opts});
    const body={id:cred.id,rawId:b64url(cred.rawId),type:cred.type,
      response:{authenticatorData:b64url(cred.response.authenticatorData),clientDataJSON:b64url(cred.response.clientDataJSON),
        signature:b64url(cred.response.signature),userHandle:cred.response.userHandle?b64url(cred.response.userHandle):null}};
    const r2=await fetch('/api/login/complete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if(r2.ok){location.href='/dashboard'}else{msg((await r2.json()).error)}
  }catch(e){msg('Error: '+e.message)}
}
