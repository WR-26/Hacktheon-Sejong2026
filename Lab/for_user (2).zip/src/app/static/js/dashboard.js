class PostCard extends HTMLElement {
  connectedCallback() {
    this.innerHTML = this.getAttribute('content') || '';
  }
}
customElements.define('post-card', PostCard);

const PURIFY_CFG = {
  FORCE_BODY: true,
  CUSTOM_ELEMENT_HANDLING: {
    tagNameCheck: /^post-/,
    attributeNameCheck: (attr) => attr === 'content' || attr === 'class',
    allowCustomizedBuiltInElements: false
  }
};

const ROOM = new URLSearchParams(location.search).get('room') || '';
const qs = ROOM ? '?room=' + encodeURIComponent(ROOM) : '';

fetch('/api/posts' + qs).then(r=>r.json()).then(posts=>{
  document.getElementById('feed').innerHTML=
    posts.map(p=>'<div class="post-item">'+DOMPurify.sanitize(p, PURIFY_CFG)+'</div>').join('');
});
if (!ROOM) {
  document.getElementById('room-ui').style.display = 'none';
  document.getElementById('no-room').style.display = '';
  document.getElementById('btn-create-room').addEventListener('click', function(){
    fetch('/api/room',{method:'POST'}).then(r=>r.json()).then(d=>{
      location.href = '/dashboard?room=' + encodeURIComponent(d.room_token);
    });
  });
} else {
  document.getElementById('btn-post').addEventListener('click', function(){
    const d = {body:document.getElementById('post-body').value, room:ROOM};
    fetch('/api/posts',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(d)}).then(()=>location.reload());
  });
  document.getElementById('btn-clear').addEventListener('click', function(){
    fetch('/api/posts',{method:'DELETE',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({room:ROOM})}).then(()=>location.reload());
  });
}
