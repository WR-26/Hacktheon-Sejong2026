CREATE TABLE IF NOT EXISTS rooms (
    id SERIAL PRIMARY KEY,
    room_token TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE,
    vault_token TEXT
);

CREATE TABLE IF NOT EXISTS creds (
    id SERIAL PRIMARY KEY,
    uid INTEGER REFERENCES users(id),
    cred_id BYTEA,
    pubkey BYTEA,
    sign_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,
    uid INTEGER REFERENCES users(id),
    body TEXT,
    room_id INTEGER REFERENCES rooms(id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS origins (
    id SERIAL PRIMARY KEY,
    origin TEXT,
    room_id INTEGER REFERENCES rooms(id)
);

CREATE INDEX IF NOT EXISTS idx_posts_room ON posts(room_id);
CREATE INDEX IF NOT EXISTS idx_origins_room ON origins(room_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_origins_unique ON origins (origin, COALESCE(room_id, -1));
