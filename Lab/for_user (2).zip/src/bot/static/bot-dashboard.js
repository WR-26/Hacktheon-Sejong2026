const $ = s => document.getElementById(s);

function fmt(s) {
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
  return h ? h + 'h ' + m + 'm' : m + 'm ' + Math.floor(s % 60) + 's';
}

function cls(s) {
  return s === 'ok' ? 's-ok' : s === 'timeout' ? 's-timeout' : 's-fail';
}

function toast(msg, ok) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast show ' + (ok ? 'ok' : 'err');
  setTimeout(() => t.className = 'toast', 2500);
}

$('btn-send').addEventListener('click', async () => {
  const url = $('url').value.trim();
  if (!url) { toast('URL is required', false); return; }
  const btn = $('btn-send');
  btn.disabled = true;
  btn.textContent = 'Sending...';
  try {
    const r = await fetch('/visit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const d = await r.json();
    if (r.ok) { toast('Queued (pos ' + d.queue + ')', true); $('url').value = ''; }
    else toast(d.error || 'Failed (' + r.status + ')', false);
  } catch (e) { toast('Network error', false); }
  btn.disabled = false;
  btn.textContent = 'Send to Bot';
});

$('url').addEventListener('keydown', e => {
  if (e.key === 'Enter') $('btn-send').click();
});

async function poll() {
  try {
    const r = await fetch('/stats');
    const d = await r.json();
    const st = $('status');
    if (!d.ready) { st.textContent = 'INIT: ' + d.init; st.className = 'pill warn'; }
    else if (d.workers_active < 1) { st.textContent = 'DOWN'; st.className = 'pill err'; }
    else if (d.queue_size > d.queue_max * .8) { st.textContent = 'HIGH LOAD'; st.className = 'pill warn'; }
    else { st.textContent = 'HEALTHY'; st.className = 'pill'; }
    $('uptime').textContent = 'Uptime ' + fmt(d.uptime_s);

    const pct = d.queue_max ? Math.min(100, d.queue_size / d.queue_max * 100) : 0;
    $('qbar').style.width = pct + '%';
    $('qbar').style.background = pct > 80
      ? 'linear-gradient(90deg,#da3633,#f85149)'
      : pct > 50
        ? 'linear-gradient(90deg,#d29922,#e3b341)'
        : 'linear-gradient(90deg,#238636,#2ea043)';
    $('qlbl').textContent = 'Queue ' + d.queue_size + '/' + d.queue_max;

    const cards = [
      ['workers_active', 'Active', '', '/ ' + d.workers_total],
      ['total', 'Processed', '', ''],
      ['ok', 'Success', 'ok', ''],
      ['fail', 'Failed', 'err', ''],
      ['timeout', 'Timeout', 'warn', ''],
      ['avg_duration', 'Avg Time', '', 's'],
      ['throughput_per_min', 'Throughput', '', '/ min'],
      ['rate_limited', 'Rate Ltd', 'warn', ''],
    ];
    let ch = '';
    for (const [k, lbl, c, suf] of cards) {
      ch += '<div class="card ' + (c || '') + '"><div class="val">' + d[k] + (suf || '') + '</div><div class="lbl">' + lbl + '</div></div>';
    }
    $('cards').innerHTML = ch;

    let th = '';
    for (const e of d.recent || []) {
      th += '<tr><td>' + e.t + '</td><td>#' + e.w + '</td><td class="' + cls(e.s) + '">' + e.s + '</td><td>' + e.d + 's</td></tr>';
    }
    $('events').innerHTML = th || '<tr><td colspan=4 style="color:#8b949e">No visits yet</td></tr>';
  } catch (e) {
    $('status').textContent = 'OFFLINE';
    $('status').className = 'pill err';
  }
}

poll();
setInterval(poll, 10000);
