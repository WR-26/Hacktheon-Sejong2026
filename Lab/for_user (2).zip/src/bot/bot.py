import asyncio, os, pathlib, time, signal, collections
from urllib.parse import urlparse
from aiohttp import web
from playwright.async_api import async_playwright

BASE_DIR = pathlib.Path(__file__).resolve().parent

APP_URL = os.environ.get("APP_URL", "https://app:3000")
APP_INTERNAL = os.environ.get("APP_INTERNAL", "http://app:3000")
ADMIN_BOOTSTRAP = os.environ.get("ADMIN_BOOTSTRAP", "")
RP_ID = os.environ.get("RP_ID", "localhost")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
PORT = int(os.environ.get("PORT", 8080))
MAX_WORKERS = int(os.environ.get("BOT_WORKERS", "20"))
MAX_QUEUE = int(os.environ.get("BOT_QUEUE", "500"))
VISIT_DURATION = int(os.environ.get("BOT_VISIT_SEC", "15"))
ROOM_COOLDOWN = int(os.environ.get("BOT_ROOM_COOLDOWN", "60"))
CLOSE_TIMEOUT = 5
VISIT_HARD_TIMEOUT = int(os.environ.get("BOT_HARD_TIMEOUT", str(VISIT_DURATION + 20)))

room_last_visit = {}
stored_credential = None
admin_cookies = None
job_queue = None
active_workers = 0
boot_time = time.time()

stats = {
    "total": 0, "ok": 0, "fail": 0, "timeout": 0,
    "rejected": 0, "rate_limited": 0,
}
recent_durations = collections.deque(maxlen=200)
recent_events = collections.deque(maxlen=50)

_spki_cache = None

def get_spki():
    global _spki_cache
    if _spki_cache:
        return _spki_cache
    cert_path = "/certs/cert.pem"
    if not os.path.exists(cert_path):
        return None
    import subprocess, hashlib, base64, time
    for _ in range(10):
        try:
            r1 = subprocess.run(["openssl", "x509", "-in", cert_path, "-pubkey", "-noout"],
                                capture_output=True)
            r2 = subprocess.run(["openssl", "pkey", "-pubin", "-outform", "der"],
                                input=r1.stdout, capture_output=True)
            if r1.returncode == 0 and r2.returncode == 0 and len(r2.stdout) > 0:
                _spki_cache = base64.b64encode(hashlib.sha256(r2.stdout).digest()).decode()
                print(f"[bot] SPKI: {_spki_cache}", flush=True)
                return _spki_cache
        except Exception:
            pass
        time.sleep(1)
    return None


def chrome_args():
    spki = get_spki()
    args = [
        "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
        "--disable-background-networking", "--disable-sync",
        "--disable-default-apps", "--no-first-run",
        "--disable-extensions", "--disable-translate",
        "--js-flags=--max-old-space-size=256",
    ]
    if spki:
        args.append(f"--ignore-certificate-errors-spki-list={spki}")
    return args


async def launch_browser(pw, extra_args=None):
    args = chrome_args() + (extra_args or [])
    try:
        return await pw.chromium.launch(headless=True, channel="chrome", args=args)
    except Exception:
        return await pw.chromium.launch(headless=True, args=args)


init_status = "starting"

async def init_admin():
    global stored_credential, admin_cookies, init_status
    init_status = "connecting"
    async with async_playwright() as p:
        from urllib.parse import urlparse
        app_host = urlparse(APP_URL).hostname
        extra = [f"--host-resolver-rules=MAP {app_host} caddy"]
        browser = await launch_browser(p, extra)
        ctx = await browser.new_context(ignore_https_errors=True)
        if ADMIN_BOOTSTRAP:
            await ctx.set_extra_http_headers({"X-Bootstrap": ADMIN_BOOTSTRAP})
        page = await ctx.new_page()

        cdp = await ctx.new_cdp_session(page)
        await cdp.send("WebAuthn.enable")
        auth = await cdp.send("WebAuthn.addVirtualAuthenticator", {
            "options": {
                "protocol": "ctap2", "transport": "internal",
                "hasResidentKey": True, "hasUserVerification": True,
                "isUserVerified": True, "automaticPresenceSimulation": True,
            }
        })

        init_status = "registering"
        await page.goto(APP_URL, wait_until="load")
        await page.wait_for_selector("#user", timeout=10000)
        await page.fill("#user", ADMIN_USER)
        await page.click("button:has-text('Register')")
        try:
            await page.wait_for_url("**/dashboard", timeout=10000)
        except Exception:
            init_status = "register failed, trying login"
            print("[bot] register failed (user may exist), trying login...", flush=True)
            await page.goto(APP_URL, wait_until="load")
            await page.wait_for_selector("#user", timeout=10000)
            await page.fill("#user", ADMIN_USER)
            await page.click("button:has-text('Login')")
            await page.wait_for_url("**/dashboard", timeout=15000)

        result = await cdp.send("WebAuthn.getCredentials",
                                {"authenticatorId": auth["authenticatorId"]})
        stored_credential = result["credentials"][0]

        admin_cookies = await ctx.cookies()
        init_status = "ready"
        print(f"[bot] admin ready, {len(admin_cookies)} cookies captured", flush=True)
        await browser.close()


async def safe_close_browser(browser):
    try:
        await asyncio.wait_for(browser.close(), timeout=CLOSE_TIMEOUT)
    except asyncio.TimeoutError:
        print("[bot] browser.close() timed out, force killing", flush=True)
        try:
            pid = browser.process.pid if browser.process else None
            if pid:
                os.kill(pid, signal.SIGKILL)
        except Exception:
            pass
    except Exception as e:
        print(f"[bot] browser.close() error: {e}", flush=True)


async def visit_with_browser(browser, url: str):
    ctx = await browser.new_context(ignore_https_errors=True)
    try:
        if admin_cookies:
            await ctx.add_cookies(admin_cookies)

        page = await ctx.new_page()
        cdp = await ctx.new_cdp_session(page)
        await cdp.send("WebAuthn.enable")
        auth = await cdp.send("WebAuthn.addVirtualAuthenticator", {
            "options": {
                "protocol": "ctap2", "transport": "internal",
                "hasResidentKey": True, "hasUserVerification": True,
                "isUserVerified": True, "automaticPresenceSimulation": True,
            }
        })
        await cdp.send("WebAuthn.addCredential", {
            "authenticatorId": auth["authenticatorId"],
            "credential": stored_credential,
        })

        print(f"[bot] visiting {url}", flush=True)
        try:
            await page.goto(url, wait_until="networkidle", timeout=15000)
        except Exception as e:
            print(f"[bot] nav error: {e}", flush=True)

        t0 = asyncio.get_event_loop().time()
        for _ in range(VISIT_DURATION * 4):
            await asyncio.sleep(0.25)
            try:
                title = await page.title()
                if "DONE" in title or "FAIL" in title:
                    elapsed = asyncio.get_event_loop().time() - t0
                    print(f"[bot] early exit ({elapsed:.1f}s): {title}", flush=True)
                    break
            except Exception:
                break
    finally:
        try:
            await ctx.close()
        except Exception:
            pass


def _log_event(wid, status, duration, url=""):
    stats["total"] += 1
    stats[status] += 1
    recent_durations.append(duration)
    path = "/" + url.split("//")[-1].split("/", 1)[-1] if url and "/" in url.split("//")[-1] else "/"
    recent_events.appendleft({
        "t": time.strftime("%H:%M:%S"), "w": wid,
        "s": status, "d": round(duration, 1), "url": path[:40],
    })


RECYCLE_AFTER = int(os.environ.get("BOT_RECYCLE", "50"))

async def worker(wid):
    global active_workers
    app_host = urlparse(APP_URL).hostname
    extra_args = [f"--host-resolver-rules=MAP {app_host} caddy"]
    while True:
        try:
            async with async_playwright() as p:
                browser = await launch_browser(p, extra_args)
                active_workers += 1
                print(f"[bot-{wid}] ready ({active_workers}/{MAX_WORKERS} active)", flush=True)
                visits = 0
                try:
                    while True:
                        job = await job_queue.get()
                        recycle = False
                        t0 = time.time()
                        status = "ok"
                        try:
                            await asyncio.wait_for(
                                visit_with_browser(browser, job["url"]),
                                timeout=VISIT_HARD_TIMEOUT,
                            )
                            visits += 1
                            if visits >= RECYCLE_AFTER:
                                recycle = True
                        except asyncio.TimeoutError:
                            print(f"[bot-{wid}] hard timeout ({VISIT_HARD_TIMEOUT}s), recycling", flush=True)
                            recycle = True
                            status = "timeout"
                        except Exception as e:
                            print(f"[bot-{wid}] error: {e}", flush=True)
                            status = "fail"
                            recycle = True
                        finally:
                            job_queue.task_done()
                            _log_event(wid, status, time.time() - t0, job.get("url", ""))
                        if recycle:
                            break
                finally:
                    await safe_close_browser(browser)
        except Exception as e:
            print(f"[bot-{wid}] playwright crashed: {e}, restarting in 2s", flush=True)
        finally:
            active_workers = max(0, active_workers - 1)
        await asyncio.sleep(1)


async def handle_visit(request):
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    url = data.get("url", "")
    room = data.get("room", "")
    if not url:
        return web.json_response({"error": "url required"}, status=400)

    now = time.time()
    rate_key = room if room else request.remote
    last = room_last_visit.get(rate_key, 0)
    if now - last < ROOM_COOLDOWN:
        wait = int(ROOM_COOLDOWN - (now - last))
        stats["rate_limited"] += 1
        return web.json_response({"error": f"rate limited, retry in {wait}s"}, status=429)
    room_last_visit[rate_key] = now

    try:
        job_queue.put_nowait({"url": url})
    except asyncio.QueueFull:
        stats["rejected"] += 1
        return web.json_response({"error": "queue full, try later"}, status=503)
    return web.json_response({"ok": True, "queue": job_queue.qsize()})


async def handle_health(request):
    return web.json_response({
        "status": "ok" if stored_credential else "initializing",
        "init": init_status,
        "ready": stored_credential is not None,
        "queue": job_queue.qsize() if job_queue else -1,
        "workers": MAX_WORKERS,
        "active_workers": active_workers,
    })


async def handle_stats(request):
    durations = list(recent_durations)
    avg_d = sum(durations) / len(durations) if durations else 0
    uptime = time.time() - boot_time
    throughput = stats["total"] / (uptime / 60) if uptime > 60 else 0
    return web.json_response({
        "uptime_s": int(uptime),
        "init": init_status,
        "ready": stored_credential is not None,
        "queue_size": job_queue.qsize() if job_queue else 0,
        "queue_max": MAX_QUEUE,
        "workers_total": MAX_WORKERS,
        "workers_active": active_workers,
        "total": stats["total"],
        "ok": stats["ok"],
        "fail": stats["fail"],
        "timeout": stats["timeout"],
        "rejected": stats["rejected"],
        "rate_limited": stats["rate_limited"],
        "avg_duration": round(avg_d, 1),
        "throughput_per_min": round(throughput, 1),
        "recent": list(recent_events),
    })


_dashboard_tpl = (BASE_DIR / "templates" / "bot-dashboard.html").read_text()


async def handle_dashboard(request):
    html = _dashboard_tpl.replace("{{APP_URL}}", APP_URL)
    return web.Response(text=html, content_type="text/html")


async def zombie_reaper():
    """Periodically reap zombie Chrome processes that outlive their browsers."""
    import subprocess
    while True:
        await asyncio.sleep(60)
        try:
            result = subprocess.run(
                ["pgrep", "-f", "chrome.*--headless"],
                capture_output=True, text=True,
            )
            pids = result.stdout.strip().split("\n") if result.stdout.strip() else []
            if len(pids) > MAX_WORKERS * 6:
                stale = pids[MAX_WORKERS * 6:]
                for pid in stale:
                    try:
                        os.kill(int(pid), signal.SIGKILL)
                    except (ProcessLookupError, ValueError):
                        pass
                print(f"[reaper] killed {len(stale)} stale chrome processes", flush=True)
        except Exception:
            pass


async def main():
    global job_queue, init_status
    job_queue = asyncio.Queue(maxsize=MAX_QUEUE)

    app = web.Application()
    app.router.add_post("/visit", handle_visit)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/stats", handle_stats)
    app.router.add_get("/", handle_dashboard)
    app.router.add_static("/static", BASE_DIR / "static")
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()
    print(f"[bot] dashboard on :{PORT}/", flush=True)

    print("[bot] initializing admin...", flush=True)
    for attempt in range(30):
        try:
            init_status = f"attempt {attempt+1}/30"
            await init_admin()
            break
        except Exception as e:
            init_status = f"attempt {attempt+1} failed: {e}"
            print(f"[bot] attempt {attempt+1}: {e}", flush=True)
            await asyncio.sleep(3)
    else:
        init_status = "FATAL: init failed after 30 attempts"
        print("[bot] FATAL: init failed", flush=True)
        await asyncio.Event().wait()

    for i in range(MAX_WORKERS):
        asyncio.create_task(worker(i))
    asyncio.create_task(zombie_reaper())
    print(f"[bot] {MAX_WORKERS} workers started, queue max {MAX_QUEUE}, "
          f"visit {VISIT_DURATION}s, hard timeout {VISIT_HARD_TIMEOUT}s, "
          f"room cooldown {ROOM_COOLDOWN}s", flush=True)

    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
