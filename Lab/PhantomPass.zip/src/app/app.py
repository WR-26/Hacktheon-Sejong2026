import os, secrets, json
import psycopg2
from flask import Flask, request, jsonify, session, make_response, render_template, redirect, g
from webauthn import (
    generate_registration_options, verify_registration_response,
    generate_authentication_options, verify_authentication_response,
)
from webauthn.helpers.structs import PublicKeyCredentialDescriptor
from webauthn.helpers import bytes_to_base64url, base64url_to_bytes, options_to_json

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))
FLAG = os.environ.get("FLAG", "hacktheon2026{placeholder}")
ORIGIN = os.environ.get("ORIGIN", "https://localhost:3000")
RP_ID = os.environ.get("RP_ID", "localhost")
DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://app:secret@db/phantompass")


def get_db():
    if "db" not in g:
        g.db = psycopg2.connect(DATABASE_URL)
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


@app.after_request
def api_headers(resp):
    if request.path.startswith("/api/") or request.path.startswith("/vault"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


def allowed_origins():
    cur = get_db().cursor()
    cur.execute("SELECT DISTINCT origin FROM origins")
    return [ORIGIN] + [r[0] for r in cur.fetchall()]


def get_room_id(token):
    if not token:
        return None
    cur = get_db().cursor()
    cur.execute("SELECT id FROM rooms WHERE room_token = %s", (token,))
    row = cur.fetchone()
    return row[0] if row else None


# ── Pages ─────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", logged_in=bool(session.get("uid")))


@app.route("/dashboard")
def dashboard():
    if not session.get("uid"):
        return redirect("/")
    nonce = secrets.token_hex(8)
    q = request.args.get("q", "")
    room = request.args.get("room", "")
    resp = make_response(render_template("dashboard.html", nonce=nonce, q=q, room=room))
    resp.headers["Cache-Control"] = "no-cache"
    return resp


# ── Room ──────────────────────────────────────────────────────

@app.route("/api/room", methods=["POST"])
def create_room():
    token = secrets.token_hex(16)
    db = get_db()
    cur = db.cursor()
    cur.execute("INSERT INTO rooms (room_token) VALUES (%s) RETURNING id", (token,))
    db.commit()
    return jsonify(room_token=token)


# ── WebAuthn ──────────────────────────────────────────────────

@app.route("/api/register/begin", methods=["POST"])
def reg_begin():
    name = request.json.get("username", "")
    if not name:
        return jsonify(error="name required"), 400
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT id FROM users WHERE name = %s", (name,))
    row = cur.fetchone()
    if row:
        cur.execute("SELECT 1 FROM creds WHERE uid = %s", (row[0],))
        if cur.fetchone():
            return jsonify(error="exists"), 409
        uid = row[0]
    else:
        cur.execute(
            "INSERT INTO users (name, vault_token) VALUES (%s, %s) RETURNING id",
            (name, secrets.token_hex(32)),
        )
        uid = cur.fetchone()[0]
        db.commit()
    session["reg_uid"] = uid
    session["uid"] = uid
    opts = generate_registration_options(
        rp_id=RP_ID, rp_name="PhantomPass",
        user_id=uid.to_bytes(8, "big"), user_name=name,
    )
    session["reg_challenge"] = bytes_to_base64url(opts.challenge)
    return make_response(options_to_json(opts), 200, {"Content-Type": "application/json"})


@app.route("/api/register/complete", methods=["POST"])
def reg_complete():
    uid = session.pop("reg_uid", None)
    ch = session.pop("reg_challenge", None)
    if not uid or not ch:
        return jsonify(error="no pending registration"), 400
    v = verify_registration_response(
        credential=request.json,
        expected_challenge=base64url_to_bytes(ch),
        expected_rp_id=RP_ID,
        expected_origin=allowed_origins(),
    )
    db = get_db()
    cur = db.cursor()
    cur.execute(
        "INSERT INTO creds (uid, cred_id, pubkey, sign_count) VALUES (%s, %s, %s, %s)",
        (uid, v.credential_id, v.credential_public_key, v.sign_count),
    )
    db.commit()
    session["uid"] = uid
    return jsonify(ok=True)


@app.route("/api/login/begin", methods=["POST"])
def login_begin():
    cur = get_db().cursor()
    cur.execute("SELECT cred_id FROM creds")
    opts = generate_authentication_options(
        rp_id=RP_ID,
        allow_credentials=[
            PublicKeyCredentialDescriptor(id=bytes(r[0])) for r in cur.fetchall()
        ],
    )
    session["login_challenge"] = bytes_to_base64url(opts.challenge)
    return make_response(options_to_json(opts), 200, {"Content-Type": "application/json"})


@app.route("/api/login/complete", methods=["POST"])
def login_complete():
    ch = session.pop("login_challenge", None)
    if not ch:
        return jsonify(error="no challenge"), 400
    db = get_db()
    cur = db.cursor()
    cur.execute(
        "SELECT id, uid, pubkey, sign_count FROM creds WHERE cred_id = %s",
        (base64url_to_bytes(request.json["id"]),),
    )
    row = cur.fetchone()
    if not row:
        return jsonify(error="unknown"), 401
    cred_db_id, uid, pubkey, _ = row
    v = verify_authentication_response(
        credential=request.json,
        expected_challenge=base64url_to_bytes(ch),
        expected_rp_id=RP_ID,
        expected_origin=allowed_origins(),
        credential_public_key=bytes(pubkey),
        credential_current_sign_count=0,
    )
    cur.execute("UPDATE creds SET sign_count = %s WHERE id = %s", (v.new_sign_count, cred_db_id))
    db.commit()
    session["uid"] = uid
    return jsonify(ok=True)


@app.route("/api/me")
def me():
    uid = session.get("uid")
    if not uid:
        return jsonify(error="auth"), 401
    cur = get_db().cursor()
    cur.execute("SELECT name, vault_token FROM users WHERE id = %s", (uid,))
    u = cur.fetchone()
    if not u:
        session.clear()
        return jsonify(error="auth"), 401
    return jsonify(name=u[0], vault_token=u[1])


# ── Posts (room-scoped) ───────────────────────────────────────

@app.route("/api/posts")
def get_posts():
    room_id = get_room_id(request.args.get("room", ""))
    if not room_id:
        return jsonify([])
    cur = get_db().cursor()
    cur.execute("SELECT body FROM posts WHERE room_id = %s ORDER BY id DESC LIMIT 50", (room_id,))
    return jsonify([r[0] for r in cur.fetchall()])


@app.route("/api/posts", methods=["POST"])
def add_post():
    uid = session.get("uid")
    if not uid:
        return jsonify(error="auth"), 401
    data = request.json or {}
    body = data.get("body") or request.form.get("body", "")
    if len(body) > 512_000:
        return jsonify(error="body too large (max 500KB)"), 413
    room_id = get_room_id(data.get("room", ""))
    if not room_id:
        return jsonify(error="room required"), 400
    db = get_db()
    cur = db.cursor()
    cur.execute("DELETE FROM posts WHERE created_at < NOW() - INTERVAL '1 hour'")
    cur.execute("SELECT COUNT(*) FROM posts WHERE room_id = %s", (room_id,))
    if cur.fetchone()[0] >= 10:
        return jsonify(error="room post limit (max 10)"), 429
    cur.execute("INSERT INTO posts (uid, body, room_id) VALUES (%s, %s, %s)", (uid, body, room_id))
    db.commit()
    return jsonify(ok=True)


@app.route("/api/posts", methods=["DELETE"])
def delete_posts():
    uid = session.get("uid")
    if not uid:
        return jsonify(error="auth"), 401
    data = request.json or {}
    room_id = get_room_id(data.get("room", ""))
    db = get_db()
    cur = db.cursor()
    if room_id:
        cur.execute("DELETE FROM posts WHERE room_id = %s AND uid = %s", (room_id, uid))
    else:
        cur.execute("DELETE FROM posts WHERE room_id IS NULL AND uid = %s", (uid,))
    db.commit()
    return jsonify(ok=True)


# ── Origins (room-scoped) ────────────────────────────────────

@app.route("/api/origins")
def list_origins():
    room_id = get_room_id(request.args.get("room", ""))
    cur = get_db().cursor()
    if room_id:
        cur.execute("SELECT origin FROM origins WHERE room_id = %s", (room_id,))
    else:
        cur.execute("SELECT origin FROM origins WHERE room_id IS NULL")
    return jsonify([r[0] for r in cur.fetchall()])


ADMIN_NAME = os.environ.get("ADMIN_USER", "admin")


@app.route("/api/origins", methods=["POST"])
def add_origin():
    uid = session.get("uid")
    if not uid:
        return jsonify(error="auth"), 401
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT name FROM users WHERE id=%s", (uid,))
    row = cur.fetchone()
    if not row or row[0] != ADMIN_NAME:
        return jsonify(error="admin only"), 403
    data = request.json or {}
    origin = data.get("origin", "")
    room_id = get_room_id(data.get("room", ""))
    if origin:
        cur.execute(
            "INSERT INTO origins (origin, room_id) VALUES (%s, %s) ON CONFLICT DO NOTHING",
            (origin, room_id),
        )
        db.commit()
    return jsonify(ok=True)


@app.route("/.well-known/webauthn")
def webauthn_json():
    return jsonify({"origins": allowed_origins()})


# ── Vault ─────────────────────────────────────────────────────

@app.route("/vault/begin", methods=["POST"])
def vault_begin():
    cur = get_db().cursor()
    cur.execute("SELECT cred_id FROM creds")
    opts = generate_authentication_options(
        rp_id=RP_ID,
        allow_credentials=[
            PublicKeyCredentialDescriptor(id=bytes(r[0])) for r in cur.fetchall()
        ],
    )
    session["vault_challenge"] = bytes_to_base64url(opts.challenge)
    return make_response(options_to_json(opts), 200, {"Content-Type": "application/json"})


@app.route("/vault", methods=["POST"])
def vault():
    ch = session.pop("vault_challenge", None)
    if not ch:
        return jsonify(error="begin first"), 400
    data = request.json
    vault_token = data.get("vault_token", "")
    cred = data.get("credential", {})
    db = get_db()
    cur = db.cursor()
    cur.execute(
        "SELECT id, uid, pubkey FROM creds WHERE cred_id = %s",
        (base64url_to_bytes(cred["id"]),),
    )
    row = cur.fetchone()
    if not row:
        return jsonify(error="unknown cred"), 401
    cred_db_id, uid, pubkey = row
    cur.execute("SELECT name, vault_token FROM users WHERE id = %s", (uid,))
    user = cur.fetchone()
    if not user or user[0] != ADMIN_NAME:
        return jsonify(error="admin only"), 403
    if vault_token != user[1]:
        return jsonify(error="bad token"), 403
    v = verify_authentication_response(
        credential=cred,
        expected_challenge=base64url_to_bytes(ch),
        expected_rp_id=RP_ID,
        expected_origin=allowed_origins(),
        credential_public_key=bytes(pubkey),
        credential_current_sign_count=0,
    )
    cur.execute("UPDATE creds SET sign_count = %s WHERE id = %s", (v.new_sign_count, cred_db_id))
    db.commit()
    return jsonify(flag=FLAG)
