#!/bin/bash
set -e

usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  -d DOMAIN    Use a custom domain (e.g. phantom.ctf-server.com)"
    echo "  -f FLAG      Set the flag (default: random)"
    echo "  -h           Show this help"
    echo ""
    echo "If no domain is given, auto-detects public IP and uses sslip.io."
    exit 0
}

CUSTOM_DOMAIN=""
CUSTOM_FLAG=""

while getopts "d:f:h" opt; do
    case $opt in
        d) CUSTOM_DOMAIN="$OPTARG" ;;
        f) CUSTOM_FLAG="$OPTARG" ;;
        h) usage ;;
        *) usage ;;
    esac
done

cd "$(dirname "$0")"

if [ -n "$CUSTOM_DOMAIN" ]; then
    APP_DOMAIN="$CUSTOM_DOMAIN"
else
    echo "[*] Detecting public IP..."
    PUBLIC_IP=$(curl -s --max-time 5 ifconfig.me || curl -s --max-time 5 icanhazip.com || curl -s --max-time 5 api.ipify.org)
    if [ -z "$PUBLIC_IP" ]; then
        echo "[-] Failed to detect public IP. Use -d to specify domain manually."
        exit 1
    fi
    SSLIP_DOMAIN=$(echo "$PUBLIC_IP" | tr '.' '-').sslip.io
    APP_DOMAIN="$SSLIP_DOMAIN"
    echo "[+] Public IP: $PUBLIC_IP"
fi

echo "[+] Domain: $APP_DOMAIN"

cat > .env <<EOF
APP_DOMAIN=$APP_DOMAIN
SECRET_KEY=$(openssl rand -hex 32)
PG_PASS=$(openssl rand -hex 16)
EOF

if [ -n "$CUSTOM_FLAG" ]; then
    echo "FLAG=$CUSTOM_FLAG" >> .env
fi

echo "[*] Generated .env"
cat .env
echo ""

echo "[*] Stopping existing services..."
sudo docker compose down 2>/dev/null || true
sudo docker volume rm web-phantom-pass_pgdata 2>/dev/null || true

echo "[*] Building and starting..."
sudo docker compose up --build -d

echo ""
echo "[*] Waiting for services to start..."
sleep 5

echo ""
echo "=================================================="
echo "  PhantomPass deployed!"
echo "  URL: https://$APP_DOMAIN/"
echo "=================================================="
echo ""
echo "Checking status..."
sudo docker compose ps
